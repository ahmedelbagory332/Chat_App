<?php 
	define('DB_USERNAME','id15332968_root');
	define('DB_PASSWORD','Diff_android288');
	define('DB_NAME','id15332968_fcm');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AAAAn73SuWs:APA91bGiv0ElpaUSoipSkEDaeAohYJ5LMrvGOY_V5TWAr7wJHpx2uPCHgAj_jDP7_AVCueJkt6gmZJ-6U_hjRp9Mb2lsECBqvyXy5jULowc5N5GEcXUggB3iu6ApZa2nO7wo3VQjSFRC');

	